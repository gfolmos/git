#importa archivos .csv
#import csv

aorden = "orden.csv"
acliente = "cliente.csv"
ares = "res.csv"
fechas = "fechas diferentes\n"

try:
    cliente = open(acliente,"r")
except FileNotFoundError:
    print("Archivo no encontrado:", cliente)
    exit()

#with open(aorden, "r") as cliente:
#     next(cliente, None) #omite encabezado
##cliente = open(acliente,"r")  
next(cliente, None) #omite encabezado
#orden = open(aorden,"r")
#next(orden, None) #omite encabezado
res = open(ares,"w")
res.write("orden" + ","+"articulo"+","+"fecha"+"\n")

for clinea in cliente:
     clinea = clinea.rstrip() #elimina salto linea
     clista = clinea.split(",")
     #print(clista)
     #print(clista[1],clista[2],clista[5],"cliente")
     #print(clista[1])

     try:
         orden = open(aorden,"r")
     except FileNotFoundError:
         print("Archivo no encontrado:", orden)
         exit()
 
     #orden = open(aorden,"r")
     next(orden, None) #omite encabezado
     for olinea in orden:
          olinea = olinea.rstrip() #elimina salto linea
          olista = olinea.split(",")
          #print(olista)
          #print(olista[1],olista[2],olista[5],"orden")
          #print(clista[1],olista[1])
          
          if clista[1] == olista[1] and clista[2] == olista[2] and clista[5] != olista[5]:
               print(clista[1],clista[2],clista[5],"res")
               res.write(clista[1]+",")
               res.write(clista[2]+",")
               res.write(clista[5]+",")
               res.write("fechas diferentes"+"\n")
               break
               
orden.close()
cliente.close()
res.close()
